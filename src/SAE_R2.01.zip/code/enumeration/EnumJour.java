package modele.enumeration;
public enum EnumJour{
    Lundi, Mardi, Mercredi, Jeudi, Vendredi, Samedi, Dimanche
}
