package modele.enumeration;
public enum EnumVacances{
    Noel, Ascension, Hiver, Ete, Toussaint, Printemps
}
